select topology.ST_NewEdgesSplit('city_data',25,'POINT(10 35)');
select topology.ST_ModEdgesSplit('city_data',27,'POINT(9.5 35)');
select topology.ST_ModEdgesSplit('city_data',28,'POINT(11 35)');
