DROP TABLE empty_raster_test;
