DROP FUNCTION makegrid(integer,integer,box2d,integer,integer);
DROP table rt_gist_grid_test;
DROP table rt_gist_query_test;
DROP type tile;

