DROP TABLE rt_properties_test;

