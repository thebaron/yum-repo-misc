rm -f loader/BasicCopy.tif
