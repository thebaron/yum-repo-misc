rm -f loader/Basic.tif
