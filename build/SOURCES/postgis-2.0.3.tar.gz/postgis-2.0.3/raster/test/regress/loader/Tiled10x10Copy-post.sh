rm -f loader/Tiled10x10Copy.tif
